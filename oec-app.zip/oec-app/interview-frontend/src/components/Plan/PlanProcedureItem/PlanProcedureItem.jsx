import React, { useState } from "react";
import ReactSelect from "react-select";
import { useParams } from "react-router-dom";
import { updateUserToProceduePlan } from "../../../api/api";

const PlanProcedureItem = ({ procedure, users, assignedUsers }) => {
    let { id } = useParams();
    const [selectedUsers, setSelectedUsers] = useState(assignedUsers);

    const handleAssignUserToProcedure = async (e) => {
        setSelectedUsers(e);        
        let xx = await updateUserToProceduePlan(id, procedure.procedureId, e.map(item => item['value']));
        console.log(xx);
    };

    return (
        <div className="py-2">
            <div>
                {procedure.procedureTitle}
            </div>

            <ReactSelect
                className="mt-2"
                placeholder="Select User to Assign"
                isMulti={true}
                options={users}
                value={selectedUsers}
                onChange={(e) => handleAssignUserToProcedure(e)}
            />
        </div>
    );
};

export default PlanProcedureItem;

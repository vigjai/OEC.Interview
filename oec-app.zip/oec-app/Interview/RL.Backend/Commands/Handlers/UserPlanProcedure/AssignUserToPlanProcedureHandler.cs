﻿using MediatR;
using RL.Backend.Commands.UserPlanProcedure;
using RL.Backend.Exceptions;
using RL.Backend.Models;
using RL.Data;
using RL.Data.DataModels;

namespace RL.Backend.Commands.Handlers.UserPlanProcedure
{
    public class AssignUserToPlanProcedureHandler : IRequestHandler<AssignUserToPlanProcedureCommand, ApiResponse<Unit>>
    {
        private readonly RLContext _context;

        public AssignUserToPlanProcedureHandler(RLContext context)
        {
            _context = context;
        }

        public async Task<ApiResponse<Unit>> Handle(AssignUserToPlanProcedureCommand request, CancellationToken cancellationToken)
        {
            try
            {
                //Validate request
                if (request.PlanId < 1)
                    return ApiResponse<Unit>.Fail(new BadRequestException("Invalid PlanId"));
                if (request.ProcedureId < 1)
                    return ApiResponse<Unit>.Fail(new BadRequestException("Invalid ProcedureId"));

                var planProcedureUser = _context.PlanProcedureUser;
                planProcedureUser.RemoveRange(
                    planProcedureUser.Where(pp => pp.PlanId == request.PlanId && pp.ProcedureId == request.ProcedureId
                    ));
                foreach (var userId in request.AssignedUsers)
                {
                    planProcedureUser.Add(new PlanProcedureUser
                    {
                        PlanId = request.PlanId,
                        UserId = userId,
                        ProcedureId = request.ProcedureId
                    });
                }

                await _context.SaveChangesAsync();

                return ApiResponse<Unit>.Succeed(new Unit());
            }
            catch (Exception e)
            {
                return ApiResponse<Unit>.Fail(e);
            }
        }
    }
}

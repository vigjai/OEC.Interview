﻿using RL.Data.DataModels;
using RL.Data.DataModels.Common;

namespace RL.Backend.Models
{
    public class PlanProcedureResponse
    {
        public int ProcedureId { get; set; }
        public int PlanId { get; set; }
        public int[]? AssignedUserIds { get; set; }
        public Procedure Procedure { get; set; }
        public Plan Plan { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}
